<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: loginPage.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About us </title>
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap"
      rel="stylesheet"
    />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="wallet-filled-money-tool.png">   
    <link rel="stylesheet" href="AboutPageStyle.css" />
  </head>
  <body>
  <nav class="sidebar">
          <ul>
              <li>  <a href="index.php" class="logo"> 
                  <img src="wallet-filled-money-tool.png" alt="">
                  <span claas ="nav-item">Rupiya</span>
                  </a> 
                  </li>
              <li><a href="account.php">
                  <i class='bx bxs-home-alt-2'>                    
                  </i>
                  <span claas ="nav-item">Home</span>
              </a>
          </li>
              <li><a href="AboutPage.php">
                  <i class='bx bxs-ghost'>
    </i>
  <span claas ="nav-item"> About</span>
              </a>
          </li>
              <li>
                  <a href="ContactUs.php"> 
                      <i class='bx bxs-contact'>
  </i>
  <span claas ="nav-item"> Contact</span>
  </a>
  </li>
              <li>  
                  <a href="logout.php" class="logout">
                      <i class='bx bx-log-out' >
                      </i>
                      <span claas ="nav-item" >Logout</span>
                  </a>
              </li>
          </ul>

          </nav>
    <div class="container">
        <div class="header">
            <h1>Our Team</h1>
    </div>

        <div class="sub-container">


            <div class="teams">
                <img  class= "handsomeboy" src="IMG-20240227-WA0039.jpg" alt="">
                <div class="name">
                    Sidharath and Aditya Kumar Singh
                </div>
                <div class="desig">
                    Designer
                </div>
                <div class="about">
                    We believer that hard work beats talent, when talent fails to work hard 
                </div>

                <div class="social-links">
                    <a href="#"><i class="fa fa-instagram"></i></a>
                    <a href="#"><i class="fa fa-github"></i></a>
                </div>
        </div>
</body>

</html>
  </body>
</html>